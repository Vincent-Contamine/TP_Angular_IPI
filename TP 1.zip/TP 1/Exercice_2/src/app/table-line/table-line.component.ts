import { Component, Input } from '@angular/core';

@Component({
  selector: '[app-table-line]',
  templateUrl: './table-line.component.html',
  styleUrls: ['./table-line.component.scss']
})
export class TableLineComponent {
  @Input() id: number = 0
  @Input() username: string = 'username'
  @Input() mail: string = 'user@mail.com'
}
