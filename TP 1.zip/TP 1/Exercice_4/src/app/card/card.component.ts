 import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.scss']
})
export class CardComponent {

  @Input() id: number = 0
  @Input() name: string = ''
  @Input() picture: string = ''
  @Input() cry: string = ''

  @Output() showCry: EventEmitter<number> = new EventEmitter<number>()


  onClickShowCry(){
    this.showCry.emit(this.id)
  }

}

