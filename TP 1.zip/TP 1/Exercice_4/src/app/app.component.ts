import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Exercice_4';

  animals: animal[] = []

  constructor(){
    this.animals.push({
      id: 1,
      name: 'Chat',
      picture: 'https://static.nationalgeographic.fr/files/styles/image_3200/public/75552.ngsversion.1422285553360.jpg?w=1600&h=900',
      cry: 'Miaou !!'
    })

    this.animals.push({
      id: 2,
      name: 'Chien',
      picture: 'https://jardinage.lemonde.fr/images/dossiers/2018-04/chien-chinois-crete-154355.jpg',
      cry: 'Waff waff !!'
    })

    this.animals.push({
      id: 3,
      name: 'vache',
      picture: 'https://www.l214.com/wp-content/uploads/2021/06/vache-noir-blanc-1024x535.jpg',
      cry: 'Meuh !!'
    })
  }

  showAnimalCry(animalId: number): void{
    const animal = this.animals.find(a =>a.id === animalId)
    if(animal) alert(`${animal.cry}`)
  }

}

interface animal {
  id: number
  name: string
  picture: string
  cry: string
}
