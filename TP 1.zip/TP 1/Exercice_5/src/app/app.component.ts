import {Component, Input} from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Exercice_5';

  car :any

  constructor(){
    this.car = {
      brand: '',
      model: ''
    }
  }

  showDetail(car :any){
    this.car = car
  }
}
