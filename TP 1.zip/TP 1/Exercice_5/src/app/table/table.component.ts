import {Component, EventEmitter, Output} from '@angular/core';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent {

  cars :car[] = []

  @Output() selectedCar :EventEmitter<any> = new EventEmitter<any>()

  constructor(){
    this.cars.push({
      id: 0,
      brand: 'Peugeot',
      model: '508'
    })

    this.cars.push({
      id: 1,
      brand: 'Renaud',
      model: 'Megane'
    })

    this.cars.push({
      id: 2,
      brand: 'Tesla',
      model: 'model 3'
    })

    this.cars.push({
      id: 3,
      brand: 'Hyudaï',
      model: 'Ioniq 5'
    })
  }

  ngOnInit(){
    this.selectedCar.emit(this.cars[0])
  }

  showNewCar(carId: number){
    this.selectedCar.emit(this.cars[carId])
  }
}
interface car{
  id :number
  brand :string
  model :string
}
