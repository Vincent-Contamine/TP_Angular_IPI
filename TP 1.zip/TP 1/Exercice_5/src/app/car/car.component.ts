import {Component, EventEmitter, Input, Output} from '@angular/core';

@Component({
  selector: '[app-car]',
  templateUrl: './car.component.html',
  styleUrls: ['./car.component.scss']
})
export class CarComponent {
  @Input() id :number = 0
  @Input() brand :string = ''
  @Input() model :string = ''

  @Output() newSelectedCar :EventEmitter<any> =new EventEmitter<any>()


  showCarDetail(){
    this.newSelectedCar.emit(this.id);
  }
}
